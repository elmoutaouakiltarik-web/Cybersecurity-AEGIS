from __future__ import annotations
from pathlib import Path
import pandas as pd
from .schema import FEATURE_COLUMNS, LABEL_COLUMNS


def load_nsl_kdd_csv(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df


def align_features(df: pd.DataFrame) -> pd.DataFrame:
    work = df.copy()
    # Remove labels if they exist.
    for c in LABEL_COLUMNS:
        if c in work.columns:
            work = work.drop(columns=[c])
    # Add missing columns conservatively.
    for c in FEATURE_COLUMNS:
        if c not in work.columns:
            work[c] = 0
    # Coerce numeric columns, preserve categorical strings.
    for c in FEATURE_COLUMNS:
        if c not in {'protocol_type', 'service', 'flag'}:
            work[c] = pd.to_numeric(work[c], errors='coerce').fillna(0)
        else:
            work[c] = work[c].astype(str).fillna('unknown')
    return work[FEATURE_COLUMNS]
