from __future__ import annotations
from typing import Dict, Any

def risk_from_prediction(binary_prediction: str, confidence: float | None, anomaly_prediction: str | None = None, anomaly_score: float | None = None) -> Dict[str, Any]:
    pred = str(binary_prediction).upper()
    conf = 0.0 if confidence is None else float(confidence)
    score = 0
    reasons = []
    if pred == 'ATTACK':
        score += 65
        reasons.append('binary_model_detected_attack')
    elif pred == 'BENIGN':
        score += 10
        reasons.append('binary_model_benign')
    else:
        score += 40
        reasons.append('unknown_binary_prediction')
    if conf >= 0.90:
        score += 15 if pred == 'ATTACK' else -5
        reasons.append('high_confidence')
    elif conf < 0.65:
        score += 10
        reasons.append('low_confidence_uncertainty')
    if anomaly_prediction and anomaly_prediction.upper() == 'ANOMALOUS':
        score += 20
        reasons.append('anomaly_model_detected_outlier')
    score = max(0, min(100, score))
    if score >= 80: level = 'critical'
    elif score >= 60: level = 'high'
    elif score >= 35: level = 'medium'
    else: level = 'low'
    return {'risk_score': score, 'risk_level': level, 'reasons': reasons}
