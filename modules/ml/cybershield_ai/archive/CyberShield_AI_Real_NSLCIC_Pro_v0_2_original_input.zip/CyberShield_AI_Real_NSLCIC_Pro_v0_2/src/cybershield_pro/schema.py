from __future__ import annotations

FEATURE_COLUMNS = [
    'duration','protocol_type','service','flag','src_bytes','dst_bytes','land','wrong_fragment','urgent','hot',
    'num_failed_logins','logged_in','num_compromised','root_shell','su_attempted','num_root','num_file_creations',
    'num_shells','num_access_files','num_outbound_cmds','is_host_login','is_guest_login','count','srv_count',
    'serror_rate','srv_serror_rate','rerror_rate','srv_rerror_rate','same_srv_rate','diff_srv_rate','srv_diff_host_rate',
    'dst_host_count','dst_host_srv_count','dst_host_same_srv_rate','dst_host_diff_srv_rate',
    'dst_host_same_src_port_rate','dst_host_srv_diff_host_rate','dst_host_serror_rate','dst_host_srv_serror_rate',
    'dst_host_rerror_rate','dst_host_srv_rerror_rate'
]

CATEGORICAL_COLUMNS = ['protocol_type', 'service', 'flag']
NUMERIC_COLUMNS = [c for c in FEATURE_COLUMNS if c not in CATEGORICAL_COLUMNS]
LABEL_COLUMNS = ['label', 'difficulty', 'binary_label', 'attack_family']

DOS = {'back','land','neptune','pod','smurf','teardrop','mailbomb','apache2','processtable','udpstorm','worm'}
PROBE = {'ipsweep','nmap','portsweep','satan','mscan','saint'}
R2L = {'ftp_write','guess_passwd','imap','multihop','phf','spy','warezclient','warezmaster','xlock','xsnoop','snmpguess','snmpgetattack','httptunnel','sendmail','named'}
U2R = {'buffer_overflow','loadmodule','perl','rootkit','ps','sqlattack','xterm'}

def attack_family(label: str) -> str:
    value = str(label).lower().strip().rstrip('.')
    if value == 'normal': return 'BENIGN'
    if value in DOS: return 'DoS'
    if value in PROBE: return 'Probe'
    if value in R2L: return 'R2L'
    if value in U2R: return 'U2R'
    return 'OtherAttack'
