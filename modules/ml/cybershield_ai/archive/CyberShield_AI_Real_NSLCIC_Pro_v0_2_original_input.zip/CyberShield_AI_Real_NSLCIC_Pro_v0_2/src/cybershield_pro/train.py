from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier, VotingClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score, balanced_accuracy_score
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from .schema import FEATURE_COLUMNS, CATEGORICAL_COLUMNS, NUMERIC_COLUMNS, attack_family
from .io import align_features


def build_preprocess():
    return ColumnTransformer([
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=True), CATEGORICAL_COLUMNS),
        ('num', StandardScaler(with_mean=False), NUMERIC_COLUMNS),
    ], remainder='drop', sparse_threshold=0.3)


def build_binary_model():
    return Pipeline([
        ('preprocess', build_preprocess()),
        ('model', VotingClassifier(estimators=[
            ('extra_trees', ExtraTreesClassifier(n_estimators=120, random_state=42, class_weight='balanced', n_jobs=1)),
            ('random_forest', RandomForestClassifier(n_estimators=100, random_state=7, class_weight='balanced_subsample', n_jobs=1)),
            ('logreg', LogisticRegression(max_iter=5000, class_weight='balanced', solver='liblinear')),
        ], voting='soft', weights=[3,2,1], n_jobs=1))
    ])


def build_family_model():
    return Pipeline([
        ('preprocess', build_preprocess()),
        ('model', ExtraTreesClassifier(n_estimators=160, random_state=99, class_weight='balanced', n_jobs=1))
    ])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--target', choices=['binary','family'], default='binary')
    ap.add_argument('--model-out', required=True)
    ap.add_argument('--report-out', required=True)
    args = ap.parse_args()
    df = pd.read_csv(args.input)
    X = align_features(df)
    if args.target == 'binary':
        if 'binary_label' in df.columns:
            y = df['binary_label'].astype(str)
        elif 'label' in df.columns:
            y = df['label'].astype(str).str.lower().map(lambda v: 'BENIGN' if v == 'normal' else 'ATTACK')
        else:
            raise ValueError('Need binary_label or label column')
        model = build_binary_model()
    else:
        if 'attack_family' in df.columns:
            y = df['attack_family'].astype(str)
        elif 'label' in df.columns:
            y = df['label'].map(attack_family)
        else:
            raise ValueError('Need attack_family or label column')
        model = build_family_model()
    min_count = int(y.value_counts().min())
    n_splits = max(2, min(5, min_count))
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    cvres = cross_validate(model, X, y, cv=cv, scoring=['accuracy','balanced_accuracy','f1_macro','f1_weighted'])
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    sha = hashlib.sha256(Path(args.input).read_bytes()).hexdigest()
    report = {
        'input_sha256': sha,
        'rows_total': int(len(df)),
        'target': args.target,
        'class_distribution': {str(k): int(v) for k,v in y.value_counts().to_dict().items()},
        'holdout_accuracy': float(accuracy_score(yte, pred)),
        'holdout_balanced_accuracy': float(balanced_accuracy_score(yte, pred)),
        'holdout_macro_f1': float(f1_score(yte, pred, average='macro')),
        'holdout_weighted_f1': float(f1_score(yte, pred, average='weighted')),
        'classification_report': classification_report(yte, pred, output_dict=True, zero_division=0),
        'confusion_matrix': confusion_matrix(yte, pred, labels=sorted(y.unique())).tolist(),
        'cv': {k: float(v.mean()) for k,v in cvres.items() if k.startswith('test_')},
    }
    model.fit(X, y)
    payload = {'model': model, 'schema': {'feature_columns': FEATURE_COLUMNS, 'categorical_columns': CATEGORICAL_COLUMNS, 'numeric_columns': NUMERIC_COLUMNS}, 'report': report}
    Path(args.model_out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report_out).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(payload, args.model_out)
    Path(args.report_out).write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
