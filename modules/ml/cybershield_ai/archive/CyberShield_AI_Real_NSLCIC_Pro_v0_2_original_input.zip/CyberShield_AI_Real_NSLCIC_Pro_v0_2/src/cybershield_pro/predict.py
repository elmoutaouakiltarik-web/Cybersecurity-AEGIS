from __future__ import annotations
import argparse
from pathlib import Path
import joblib
import pandas as pd
import numpy as np
from .io import align_features
from .risk import risk_from_prediction


def load_payload(model_path: str | Path):
    return joblib.load(model_path)


def predict_csv(model_path: str, input_path: str, output_path: str, anomaly_model_path: str | None = None) -> None:
    payload = load_payload(model_path)
    df = pd.read_csv(input_path)
    X = align_features(df)
    model = payload['model']
    out = df.copy()
    pred = model.predict(X)
    out['cybershield_prediction'] = pred
    confidences = [None] * len(out)
    if hasattr(model, 'predict_proba'):
        proba = model.predict_proba(X)
        classes = [str(c) for c in model.named_steps['model'].classes_] if hasattr(model, 'named_steps') else [str(c) for c in model.classes_]
        out['cybershield_confidence'] = proba.max(axis=1)
        confidences = out['cybershield_confidence'].tolist()
        for i, c in enumerate(classes):
            out[f'proba_{c}'] = proba[:, i]
    anomaly_labels = [None] * len(out)
    anomaly_scores = [None] * len(out)
    if anomaly_model_path:
        ap = load_payload(anomaly_model_path)
        am = ap['model']
        raw = am.predict(X)
        scores = am.decision_function(X)
        anomaly_labels = ['BENIGN_LIKE' if p == 1 else 'ANOMALOUS' for p in raw]
        anomaly_scores = scores.tolist()
        out['cybershield_anomaly_prediction'] = anomaly_labels
        out['cybershield_anomaly_score'] = scores
    risk_rows = [risk_from_prediction(str(pred[i]), confidences[i], anomaly_labels[i], anomaly_scores[i]) for i in range(len(out))]
    out['cybershield_risk_score'] = [r['risk_score'] for r in risk_rows]
    out['cybershield_risk_level'] = [r['risk_level'] for r in risk_rows]
    out['cybershield_risk_reasons'] = [';'.join(r['reasons']) for r in risk_rows]
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_path, index=False)
    print(f'Saved predictions to {output_path}')


def main() -> None:
    p = argparse.ArgumentParser(description='CyberShield Pro NSL-KDD predictor')
    p.add_argument('--model', required=True)
    p.add_argument('--input', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--anomaly-model', default=None)
    args = p.parse_args()
    predict_csv(args.model, args.input, args.output, args.anomaly_model)

if __name__ == '__main__':
    main()
