# Zeek integration

Use Zeek flow/log metadata to build NSL-KDD-like feature windows or train a native Zeek feature schema.
Recommended pipeline:
1. Zeek conn.log/http.log/dns.log -> feature aggregator.
2. Aggregator outputs CSV/JSON with stable columns.
3. CyberShield API returns prediction/risk.
4. SIEM receives enriched alert.

Do not use raw IP addresses as primary ML features; keep identity/asset mapping outside the model.
