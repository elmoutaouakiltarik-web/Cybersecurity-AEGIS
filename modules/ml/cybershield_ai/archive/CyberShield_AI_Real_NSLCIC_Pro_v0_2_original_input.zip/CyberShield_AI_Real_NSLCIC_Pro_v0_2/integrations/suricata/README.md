# Suricata integration

Suricata eve.json can enrich the model input with flow metadata, alert categories and severity.
The AI output should enrich existing IDS alerts, not replace deterministic signatures.
