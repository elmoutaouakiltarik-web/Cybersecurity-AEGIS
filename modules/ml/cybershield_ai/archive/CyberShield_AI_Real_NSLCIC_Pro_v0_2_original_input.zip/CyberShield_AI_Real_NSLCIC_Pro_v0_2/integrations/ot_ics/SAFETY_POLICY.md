# OT/ICS safety policy

CyberShield AI v0.2 must be used in OT/ICS as alert-only by default.

Allowed automatically:
- passive monitoring
- risk scoring
- dashboard alert
- ticket creation
- packet/log enrichment

Requires human approval:
- any block/quarantine in an industrial segment
- PLC/SCADA/RTU/IED interaction
- patch or restart
- firewall rule changing production flows

Forbidden by default:
- automatic shutdown
- automatic PLC write
- unauthorised scanning of fragile OT devices
