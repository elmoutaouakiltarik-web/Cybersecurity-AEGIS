from __future__ import annotations
import joblib
import pandas as pd
import streamlit as st
from cybershield_pro.io import align_features
from cybershield_pro.risk import risk_from_prediction

st.set_page_config(page_title='CyberShield AI Pro', layout='wide')
st.title('CyberShield AI Pro v0.2')
st.caption('Defensive AI IDS/NDR trained on real NSL-KDD subset from the provided base package.')

binary_path = st.text_input('Binary model', 'models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib')
family_path = st.text_input('Family model', 'models/cybershield_pro_nsl_kdd_family_classifier_v0_2.joblib')
anomaly_path = st.text_input('Anomaly model', 'models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib')
uploaded = st.file_uploader('CSV NSL-KDD compatible', type=['csv'])
if uploaded:
    df = pd.read_csv(uploaded)
    X = align_features(df)
    b = joblib.load(binary_path)['model']
    out = df.copy()
    out['binary_prediction'] = b.predict(X)
    proba = b.predict_proba(X)
    out['confidence'] = proba.max(axis=1)
    if family_path:
        out['family_prediction'] = joblib.load(family_path)['model'].predict(X)
    if anomaly_path:
        am = joblib.load(anomaly_path)['model']
        out['anomaly_prediction'] = ['BENIGN_LIKE' if p == 1 else 'ANOMALOUS' for p in am.predict(X)]
        out['anomaly_score'] = am.decision_function(X)
    risks = [risk_from_prediction(str(row.binary_prediction), float(row.confidence), getattr(row, 'anomaly_prediction', None), getattr(row, 'anomaly_score', None)) for row in out.itertuples()]
    out['risk_score'] = [r['risk_score'] for r in risks]
    out['risk_level'] = [r['risk_level'] for r in risks]
    st.dataframe(out, use_container_width=True)
    st.download_button('Scarica predizioni CSV', out.to_csv(index=False), file_name='cybershield_predictions.csv')
