$ErrorActionPreference = "Stop"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:PYTHONPATH = "$PWD\src"
python -m cybershield_pro.predict --model models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib --anomaly-model models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib --input examples/nsl_kdd_real_input_example.csv --output reports/windows_predictions.csv
Write-Host "OK: reports/windows_predictions.csv creato"
Write-Host "API:  $env:PYTHONPATH='$PWD\src'; uvicorn api.app:app --host 0.0.0.0 --port 8919"
