# Metti KDDTrain+.txt o KDDTrain+.csv in data/real/ e aggiorna il path sotto.
$ErrorActionPreference = "Stop"
$env:PYTHONPATH = "$PWD\src"
python -m cybershield_pro.train `
  --input data/real/KDDTrain+.csv `
  --target binary `
  --model-out models/cybershield_pro_nsl_kdd_binary_full.joblib `
  --report-out reports/full_nsl_kdd_binary_report.json
python -m cybershield_pro.train `
  --input data/real/KDDTrain+.csv `
  --target family `
  --model-out models/cybershield_pro_nsl_kdd_family_full.joblib `
  --report-out reports/full_nsl_kdd_family_report.json
