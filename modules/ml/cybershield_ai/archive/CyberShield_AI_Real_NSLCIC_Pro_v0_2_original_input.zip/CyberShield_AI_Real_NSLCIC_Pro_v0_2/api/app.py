from __future__ import annotations
import os
from pathlib import Path
from typing import Any, Dict
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from cybershield_pro.io import align_features
from cybershield_pro.risk import risk_from_prediction

BINARY_MODEL_PATH = os.getenv('CYBERSHIELD_BINARY_MODEL', 'models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib')
FAMILY_MODEL_PATH = os.getenv('CYBERSHIELD_FAMILY_MODEL', 'models/cybershield_pro_nsl_kdd_family_classifier_v0_2.joblib')
ANOMALY_MODEL_PATH = os.getenv('CYBERSHIELD_ANOMALY_MODEL', 'models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib')

app = FastAPI(title='CyberShield AI Pro API', version='0.2.0')
models: Dict[str, Any] = {}

class Event(BaseModel):
    features: Dict[str, Any] = Field(..., description='NSL-KDD compatible feature dictionary')

@app.on_event('startup')
def startup():
    for name, path in [('binary', BINARY_MODEL_PATH), ('family', FAMILY_MODEL_PATH), ('anomaly', ANOMALY_MODEL_PATH)]:
        if Path(path).exists():
            models[name] = joblib.load(path)

@app.get('/health')
def health():
    return {'ok': True, 'loaded_models': sorted(models.keys())}

@app.post('/predict')
def predict(event: Event):
    if 'binary' not in models:
        raise HTTPException(503, 'Binary model not loaded')
    df = pd.DataFrame([event.features])
    X = align_features(df)
    bm = models['binary']['model']
    pred = str(bm.predict(X)[0])
    conf = None
    probabilities = None
    if hasattr(bm, 'predict_proba'):
        p = bm.predict_proba(X)[0]
        classes = [str(c) for c in bm.named_steps['model'].classes_]
        probabilities = {classes[i]: float(p[i]) for i in range(len(classes))}
        conf = float(max(p))
    family = None
    if 'family' in models:
        family = str(models['family']['model'].predict(X)[0])
    anomaly_pred = None
    anomaly_score = None
    if 'anomaly' in models:
        am = models['anomaly']['model']
        raw = am.predict(X)[0]
        anomaly_pred = 'BENIGN_LIKE' if raw == 1 else 'ANOMALOUS'
        anomaly_score = float(am.decision_function(X)[0])
    risk = risk_from_prediction(pred, conf, anomaly_pred, anomaly_score)
    return {
        'binary_prediction': pred,
        'confidence': conf,
        'probabilities': probabilities,
        'family_prediction': family,
        'anomaly_prediction': anomaly_pred,
        'anomaly_score': anomaly_score,
        **risk,
        'recommended_action': 'investigate' if risk['risk_score'] >= 35 else 'monitor'
    }
