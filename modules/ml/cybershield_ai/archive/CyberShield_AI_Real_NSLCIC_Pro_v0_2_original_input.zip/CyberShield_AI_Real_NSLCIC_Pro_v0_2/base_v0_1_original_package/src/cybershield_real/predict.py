
from __future__ import annotations
import argparse, json
from pathlib import Path
import joblib
import pandas as pd


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model', default='models/cybershield_nsl_kdd_real_binary_v0_1.joblib')
    p.add_argument('--input', required=True)
    p.add_argument('--output', default='reports/predictions.csv')
    args=p.parse_args()
    payload=joblib.load(args.model)
    model=payload['model']
    features=payload['schema']['input_features']
    df=pd.read_csv(args.input)
    X=df[features].copy()
    preds=model.predict(X)
    out=df.copy()
    out['cybershield_prediction']=preds
    if hasattr(model, 'predict_proba'):
        proba=model.predict_proba(X)
        out['cybershield_confidence']=proba.max(axis=1)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    print(json.dumps({'saved':args.output,'rows':len(out)}, indent=2))

if __name__=='__main__':
    main()
