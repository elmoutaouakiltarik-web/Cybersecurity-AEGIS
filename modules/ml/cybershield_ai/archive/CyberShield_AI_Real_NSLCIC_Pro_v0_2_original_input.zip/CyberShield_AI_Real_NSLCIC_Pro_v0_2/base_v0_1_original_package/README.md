
# CyberShield Real NSL-KDD Trained Model

Questo pacchetto contiene un **modello AI difensivo già addestrato su dati reali NSL-KDD**, non su dati sintetici e non su una demo inventata.

## Modelli inclusi

- `models/cybershield_nsl_kdd_real_binary_v0_1.joblib`  
  Classificazione binaria: `BENIGN` vs `ATTACK`.

- `models/cybershield_nsl_kdd_real_family_v0_1.joblib`  
  Classificazione famiglia: `BENIGN`, `DoS`, `Probe`, `R2L`.

- `models/cybershield_nsl_kdd_real_anomaly_v0_1.joblib`  
  Anomaly model addestrato su traffico benigno reale del subset.

## Fonte dei dati

Fonte usata: repository pubblico `Jehuty4949/NSL_KDD`, file `Small Training Set.csv`.

Il repository espone anche `KDDTrain+.csv`, `KDDTest+.csv`, `KDDTrain+.txt`, `KDDTest+.txt`, `KDDTest-21.txt` e altri file NSL-KDD.

## Report training

Metriche principali:

```json
{
  "rows_total": 122,
  "rows_train": 91,
  "rows_test": 31,
  "class_distribution_total": {
    "ATTACK": 70,
    "BENIGN": 52
  },
  "accuracy_holdout": 0.9354838709677419,
  "macro_f1_holdout": 0.9348739495798319,
  "weighted_f1_holdout": 0.9358904852263487,
  "dataset_subset_sha256": "e8293e2a6d1e2bf080363a677183cc17e35f8ed9bea2d0db21e0e9740bab4016"
}
```

## Uso rapido

Installa dipendenze:

```bash
pip install pandas scikit-learn joblib fastapi uvicorn
```

Predizione batch:

```bash
PYTHONPATH=src python -m cybershield_real.predict \
  --model models/cybershield_nsl_kdd_real_binary_v0_1.joblib \
  --input examples/sample_real_nsl_kdd_input.csv \
  --output reports/predictions.csv
```

API:

```bash
uvicorn api.app:app --host 0.0.0.0 --port 8919
```

## Importante

Questo è un modello vero addestrato su NSL-KDD, ma è una **base v0.1**. Per produzione seria devi riaddestrare su full `KDDTrain+.csv` e testare su `KDDTest+.csv`, poi aggiungere CIC-IDS2017, UNSW-NB15 e TON_IoT.

Non usare questo modello per bloccare automaticamente PLC/SCADA/OT. In ambienti industriali usa solo alert read-only + approvazione umana.
