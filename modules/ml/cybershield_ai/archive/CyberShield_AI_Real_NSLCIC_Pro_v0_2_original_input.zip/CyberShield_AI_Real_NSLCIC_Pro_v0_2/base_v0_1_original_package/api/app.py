
from __future__ import annotations
import os
from typing import Any, Dict, List
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

MODEL_PATH=os.getenv('CYBERSHIELD_MODEL','models/cybershield_nsl_kdd_real_binary_v0_1.joblib')
app=FastAPI(title='CyberShield Real NSL-KDD Model API', version='0.1.0')
payload=None

class Event(BaseModel):
    features: Dict[str, Any]

@app.on_event('startup')
def load():
    global payload
    if os.path.exists(MODEL_PATH):
        payload=joblib.load(MODEL_PATH)

@app.get('/health')
def health():
    return {'ok': True, 'model_loaded': payload is not None, 'model_path': MODEL_PATH}

@app.post('/predict')
def predict(event: Event):
    if payload is None:
        raise HTTPException(status_code=503, detail='Model not loaded')
    features=payload['schema']['input_features']
    df=pd.DataFrame([event.features])
    missing=[f for f in features if f not in df.columns]
    if missing:
        raise HTTPException(status_code=400, detail={'missing_features': missing})
    X=df[features]
    model=payload['model']
    pred=str(model.predict(X)[0])
    res={'prediction': pred, 'risk': 'low' if pred=='BENIGN' else 'high'}
    try:
        proba=model.predict_proba(X)[0]
        classes=[str(c) for c in model.classes_]
        res['confidence']=float(proba.max())
        res['probabilities']={classes[i]:float(proba[i]) for i in range(len(classes))}
    except Exception:
        pass
    return res
