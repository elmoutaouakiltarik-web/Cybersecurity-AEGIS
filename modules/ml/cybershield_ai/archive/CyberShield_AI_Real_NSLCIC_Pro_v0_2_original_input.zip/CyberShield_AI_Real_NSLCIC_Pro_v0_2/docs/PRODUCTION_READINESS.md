# Production readiness checklist

## Data
- [ ] Train on full KDDTrain+ and validate on KDDTest+.
- [ ] Add CIC-IDS2017, UNSW-NB15 and TON_IoT.
- [ ] Validate on customer-approved traffic.
- [ ] Measure false positives per site.

## Engineering
- [ ] CI tests for schema drift.
- [ ] Model versioning and rollback.
- [ ] Canary deployment.
- [ ] Audit log for every prediction.
- [ ] Signed model artifacts.

## SOC
- [ ] Wazuh integration.
- [ ] Zeek/Suricata enrichment.
- [ ] Incident timeline.
- [ ] Analyst feedback loop.

## OT/ICS
- [ ] Alert-only default.
- [ ] Human approval before containment.
- [ ] Passive SPAN/TAP monitoring.
- [ ] No unauthorised active scans.
