# Model Card — CyberShield Pro NSL-KDD Binary Ensemble v0.2

## Intended use

Defensive network intrusion detection, SOC triage, SIEM enrichment and educational/research validation.

## Not intended use

- Offensive operations
- Automated attack generation
- Automatic PLC/SCADA shutdown
- Production blocking without validation on customer traffic

## Training data

Real NSL-KDD subset inherited from the provided base artifact.

- Rows: 122
- SHA256: `371aafb74a9174a98b0081d56d0570b3e081848d2259d44679297a6aa3b8786d`
- Labels: {"ATTACK": 70, "BENIGN": 52}

## Performance

- Holdout accuracy: 0.9355
- Holdout balanced accuracy: 0.9444
- Holdout macro F1: 0.9349
- CV macro F1 mean/std: 0.9665 / 0.0314

## Limitations

The dataset slice is real but small. Use this as a true starter model, not as a final production IDS. Production requires full datasets and customer-specific validation.
