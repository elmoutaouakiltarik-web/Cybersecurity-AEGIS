# Model Card — CyberShield Pro NSL-KDD Family Classifier v0.2

Classifies events into BENIGN / DoS / Probe / R2L based on the real rows available in the base package.

- Holdout accuracy: 1.0000
- Holdout macro F1: 1.0000
- Classes: BENIGN, DoS, Probe, R2L

Limit: the provided subset has no U2R samples, so the current packaged model cannot honestly learn U2R. The mapping is included for retraining on full NSL-KDD.
