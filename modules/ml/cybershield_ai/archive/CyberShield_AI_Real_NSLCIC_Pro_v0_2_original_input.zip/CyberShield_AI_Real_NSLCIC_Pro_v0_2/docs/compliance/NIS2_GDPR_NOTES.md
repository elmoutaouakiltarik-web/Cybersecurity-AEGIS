# NIS2 / GDPR notes

CyberShield AI can support evidence collection, incident timeline, asset visibility, detection and response records.

Design requirements:
- minimization of personal data in logs;
- retention policy per customer/site;
- access control and audit trail;
- encryption in transit and at rest;
- incident report export;
- supplier and model provenance tracking;
- separation between IT response and OT/ICS safety-critical operations.
