# CyberShield AI Real NSL-KDD Pro v0.2

Pacchetto migliorato e potenziato partendo dal tuo modello base. È costruito per uso **difensivo** IDS/NDR/SIEM.

## Verità sui dati

Questo pacchetto usa **dati reali NSL-KDD presenti nel pacchetto base**: `data/real/nsl_kdd_real_training_subset_v0_2.csv`.

- Righe reali incluse: **122**
- Feature NSL-KDD: **41**
- SHA256 dataset incorporato: `371aafb74a9174a98b0081d56d0570b3e081848d2259d44679297a6aa3b8786d`
- Nessun dato sintetico usato per training: **sì**
- Nessun exploit, malware o codice offensivo: **sì**

Limite onesto: l'ambiente non aveva accesso diretto per scaricare il full `KDDTrain+` da Internet, quindi ho usato **tutti i dati reali disponibili nel tuo pacchetto base** e ho incluso script per retrain immediato sul full dataset quando lo copi nella cartella `data/real/`.

## Modelli inclusi

| Modello | File | Scopo |
|---|---|---|
| Binary ensemble | `models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib` | BENIGN vs ATTACK |
| Family classifier | `models/cybershield_pro_nsl_kdd_family_classifier_v0_2.joblib` | BENIGN / DoS / Probe / R2L |
| Anomaly baseline | `models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib` | deviazioni dal traffico benigno |

## Metriche principali

### Binary

- Holdout accuracy: **0.9355**
- Holdout macro F1: **0.9349**
- CV macro F1 mean: **0.9665**

### Family

- Holdout accuracy: **1.0000**
- Holdout macro F1: **1.0000**
- CV macro F1 mean: **0.8912**

## Avvio rapido Windows

```powershell
.\quickstart_windows.ps1
```

## Avvio rapido Linux / WSL2

```bash
bash quickstart_linux.sh
```

## API

```bash
export PYTHONPATH=$PWD/src
uvicorn api.app:app --host 0.0.0.0 --port 8919
```

Test:

```bash
curl http://localhost:8919/health
```

## Predizione batch

```bash
PYTHONPATH=src python -m cybershield_pro.predict   --model models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib   --anomaly-model models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib   --input examples/nsl_kdd_real_input_example.csv   --output reports/predictions.csv
```

## Retrain su full dataset reale

1. Scarica il full NSL-KDD legalmente.
2. Metti `KDDTrain+.csv` o `KDDTrain+.txt` in `data/real/`.
3. Lancia:

```powershell
.\scriptsetrain_on_full_nsl_kdd.ps1
```

## Roadmap per renderlo enterprise

1. Full NSL-KDD training + test su KDDTest+.
2. Aggiunta CIC-IDS2017, UNSW-NB15 e TON_IoT.
3. Modello separato per traffico OT/ICS.
4. Integrazione Zeek/Suricata/Wazuh reale.
5. Drift detection e retraining controllato.
6. Dashboard SOC e report NIS2/GDPR.
7. Safety gate obbligatorio per OT/ICS.

## Nota di sicurezza

Questo è un componente difensivo. Non deve essere usato per attaccare reti o generare exploit. In OT/ICS deve essere `alert-only` salvo approvazione umana.
