#!/usr/bin/env bash
set -euo pipefail
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH="$PWD/src"
python -m cybershield_pro.predict --model models/cybershield_pro_nsl_kdd_binary_ensemble_v0_2.joblib --anomaly-model models/cybershield_pro_nsl_kdd_anomaly_baseline_v0_2.joblib --input examples/nsl_kdd_real_input_example.csv --output reports/linux_predictions.csv
echo "OK: reports/linux_predictions.csv creato"
